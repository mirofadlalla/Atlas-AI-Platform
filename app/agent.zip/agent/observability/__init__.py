# Agent observability helpers
