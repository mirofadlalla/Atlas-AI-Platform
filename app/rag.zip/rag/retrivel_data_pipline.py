import os
import sys
import threading
from pathlib import Path
import logging
import hashlib
import time
from cachetools import TTLCache
from langchain_redis import RedisSemanticCache
from langchain_core.globals import set_llm_cache, get_llm_cache
from langchain_classic.chains import create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain
from langchain_classic.prompts import ChatPromptTemplate
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

from app.models.runs import Runs
from app.models.costLog import CostLog
from app.rag.rerankers import RankingService
from app.repositories.runs_repository import RunsRepository
from app.repositories.cost_log_repository import CostLogRepository
from app.services.rag_services.query_logging_service import trigger_query_logging
from app.core.monitors import (
    cache_hits_total,
    cache_misses_total,
    vector_search_queries_total,
    vector_search_duration_seconds,
    retrieved_chunks_count,
    reranking_queries_total,
    reranking_duration_seconds
)
from app.core.config import settings  # Import settings for Redis config

# Setup paths
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from app.rag.steps.retriever import get_retriever
from app.services.llm_runner import CustomLocalLLM
from app.design_pattern.embedded_model import EmbeddedModel  # Ensure it's LangChain compatible

# Initialize the embedding model singleton once at module load time
_embedding_model = EmbeddedModel()

# Initialize reranker singletons per strategy
_ranking_services = {}
_ranking_services_lock = threading.Lock()


def _get_ranking_service(strategy: str = "hybrid"):
    """Get or create a RankingService singleton for the given strategy (thread-safe)."""
    if strategy not in _ranking_services:
        with _ranking_services_lock:
            # Double-checked locking to avoid duplicate initialization under concurrency
            if strategy not in _ranking_services:
                logger.info(f"Initializing RankingService with strategy: {strategy}")
                _ranking_services[strategy] = RankingService(strategy=strategy)
    return _ranking_services[strategy]


# Initialize LLM singleton once at module load time
logger.info("Initializing CustomLocalLLM singleton")
_cached_llm = CustomLocalLLM()
logger.info("CustomLocalLLM singleton ready")

# ---------------------------------------------------------------------------
# FIX #4 (Thread-safety / TTL): local query cache using cachetools.TTLCache
# instead of a plain dict. TTLCache handles expiry + is safe to guard with a
# single lock for read/write/evict operations (plain dict + manual TTL loop
# was not atomic under concurrent requests).
# Cache keys already include tenant_id (see _build_cache_key), so this cache
# was NOT the tenant-isolation bug -- only the Redis semantic cache was.
# ---------------------------------------------------------------------------
_QUERY_CACHE_MAXSIZE = 10_000
_QUERY_CACHE_TTL_SECONDS = 3600  # 1 hour TTL
_query_cache = TTLCache(maxsize=_QUERY_CACHE_MAXSIZE, ttl=_QUERY_CACHE_TTL_SECONDS)
_query_cache_lock = threading.Lock()

# Token pricing now lives in settings (see FIX #7) so it can be updated in one
# place if the underlying model or provider pricing changes.
_DEFAULT_INPUT_TOKEN_COST = 0.0000001
_DEFAULT_OUTPUT_TOKEN_COST = 0.0000002
_INPUT_TOKEN_COST = getattr(settings, "QWEN_INPUT_TOKEN_COST", _DEFAULT_INPUT_TOKEN_COST)
_OUTPUT_TOKEN_COST = getattr(settings, "QWEN_OUTPUT_TOKEN_COST", _DEFAULT_OUTPUT_TOKEN_COST)


class RetrievalPipeline:
    def __init__(self, tenant_id: int, use_reranker: bool = True, reranker_strategy: str = None, db: Session = None):
        """
        Initialize the retrieval pipeline with optional reranking.

        Args:
            tenant_id: Tenant identifier
            use_reranker: Whether to use document reranking
            reranker_strategy: Reranking strategy ('cross-encoder', 'bm25', 'hybrid')
            db: Optional SQLAlchemy Session for saving runs and costs to database
        """
        self.tenant_id = tenant_id
        self.retriever = get_retriever(tenant_id)
        self.use_reranker = use_reranker
        self.db = db
        self.runs_repo = RunsRepository(db) if db else None
        self.cost_repo = CostLogRepository(db) if db else None

        # Initialize reranker if enabled - use cached singleton
        if use_reranker:
            self.ranking_service = _get_ranking_service(strategy=reranker_strategy)
        else:
            self.ranking_service = None

        # 1. Define the embedding model (Object)
        # Use the singleton instance so Redis can use it for similarity comparison
        self.embedding_model = _embedding_model

        # ---------------------------------------------------------------
        # FIX #1 (CRITICAL - tenant cache isolation):
        # langchain's set_llm_cache()/get_llm_cache() store a SINGLE GLOBAL
        # cache instance for the whole process. Because RedisSemanticCache
        # matches on embedding *similarity* (distance_threshold=0.2), a
        # semantically similar question from Tenant B could previously be
        # served an answer that was generated from Tenant A's private
        # documents -- a cross-tenant data leak.
        #
        # Fix: give every tenant its own logical cache namespace inside the
        # SAME Redis instance/DB, and make sure the semantic key used for
        # similarity lookups always includes the tenant_id so two tenants
        # can never match each other's cached vectors. We do this by:
        #   (a) keeping one RedisSemanticCache per tenant_id (namespaced by
        #       a tenant-specific prefix), cached in a module-level dict, and
        #   (b) never sharing that cache instance across tenants.
        # ---------------------------------------------------------------
        self._init_tenant_scoped_cache()

        # 3. Setup Local LLM and Chain - use cached singleton
        self.local_llm = _cached_llm

        prompt = ChatPromptTemplate.from_template(
            "Answer the following question based only on the provided context:\n\n"
            "Context: {context}\n\n"
            "Question: {input}\n\n"
            "Answer:"
        )

        self.document_chain = create_stuff_documents_chain(self.local_llm, prompt)
        self.qa_chain = create_retrieval_chain(self.retriever, self.document_chain)

    # -------------------------------------------------------------------
    # FIX #1 helper: per-tenant Redis semantic cache
    # -------------------------------------------------------------------
    _tenant_caches = {}
    _tenant_caches_lock = threading.Lock()

    def _init_tenant_scoped_cache(self):
        """
        Create (or reuse) a RedisSemanticCache scoped to this tenant only.

        Each tenant gets its own cache_name/prefix in Redis, so semantic
        similarity lookups can never cross tenant boundaries, even though
        they all share the same Redis server.
        """
        cache_key = f"tenant:{self.tenant_id}"

        if cache_key in RetrievalPipeline._tenant_caches:
            self.llm_cache = RetrievalPipeline._tenant_caches[cache_key]
            set_llm_cache(self.llm_cache)
            return

        with RetrievalPipeline._tenant_caches_lock:
            if cache_key in RetrievalPipeline._tenant_caches:
                self.llm_cache = RetrievalPipeline._tenant_caches[cache_key]
                set_llm_cache(self.llm_cache)
                return

            logger.info(
                f"Initializing tenant-scoped Redis Semantic Cache for tenant "
                f"{self.tenant_id} at {settings.redis_host}:{settings.redis_port}"
            )
            try:
                import redis
                logger.info(f"Testing Redis connection to {settings.REDIS_URL_NO_DB}...")
                redis_client = redis.from_url(settings.REDIS_URL_NO_DB)
                redis_client.ping()
                logger.info("✅ Redis connection verified")

                cache = RedisSemanticCache(
                    redis_url=settings.REDIS_URL_NO_DB,
                    embeddings=self.embedding_model,
                    ttl=86400,  # one day
                    distance_threshold=0.2,
                    # Namespacing the cache index per tenant is what actually
                    # prevents cross-tenant matches -- two tenants never read
                    # from or write to the same underlying Redis index.
                    name=f"llm_semantic_cache_tenant_{self.tenant_id}",
                )
                RetrievalPipeline._tenant_caches[cache_key] = cache
                self.llm_cache = cache
                set_llm_cache(cache)
                logger.info(
                    f"✅ Redis Semantic Cache initialized for tenant {self.tenant_id} "
                    f"- TTL: 24h, Distance threshold: 0.2"
                )
            except Exception as e:
                logger.error(f"❌ Failed to initialize Redis cache for tenant {self.tenant_id}: {e}")
                logger.warning("Continuing without Redis cache - LLM responses will NOT be cached")
                logger.info("Troubleshooting: Ensure Redis is running and accessible at " + settings.REDIS_URL_NO_DB)
                RetrievalPipeline._tenant_caches[cache_key] = None
                self.llm_cache = None
                set_llm_cache(None)

    def retrieve(self, query: str, top_k: int = 10, fetch_multiplier: int = 2):
        """
        Retrieve relevant documents for a query with optional reranking.

        For better reranking results, fetches more documents initially,
        then reranks down to top_k.

        Args:
            query: User query
            top_k: Number of top documents to return
            fetch_multiplier: Multiplier for initial fetch (e.g., 2 means fetch 2x top_k)

        Returns:
            List of relevant documents (reranked if enabled)
        """
        start_time = time.time()

        # Fetch more docs initially for better reranking (if enabled)
        fetch_count = max(top_k * fetch_multiplier, top_k) if self.use_reranker else top_k

        # -----------------------------------------------------------
        # FIX #2: fetch_count was computed but never actually passed to
        # the retriever, so the reranker was always working off the
        # retriever's default k (5), regardless of fetch_multiplier.
        # We now explicitly request fetch_count documents.
        #
        # LangChain's VectorStoreRetriever accepts a `k` override via
        # invoke()'s kwargs, which gets merged into search_kwargs for
        # this call only (it does not mutate the cached, shared
        # retriever instance).
        # -----------------------------------------------------------
        try:
            docs = self.retriever.invoke(query, k=fetch_count)
        except TypeError:
            # Fallback for retriever implementations that don't accept
            # a `k` override on invoke() -- rebuild search_kwargs safely
            # without mutating the shared/cached retriever.
            base_kwargs = dict(getattr(self.retriever, "search_kwargs", {}) or {})
            base_kwargs["k"] = fetch_count
            docs = self.retriever.vectorstore.as_retriever(
                search_kwargs=base_kwargs
            ).invoke(query)

        retrieval_time = time.time() - start_time
        logger.debug(f"Document retrieval took {retrieval_time:.3f}s, got {len(docs)} documents")

        # Track retrieval metrics
        vector_search_queries_total.labels(tenant_id=str(self.tenant_id)).inc()
        vector_search_duration_seconds.observe(retrieval_time)
        retrieved_chunks_count.observe(len(docs))

        # Sort by ID to ensure deterministic ordering for caching
        docs = sorted(docs, key=lambda d: d.metadata.get('_id', ''))

        # Apply reranking if enabled
        if self.use_reranker and self.ranking_service and docs:
            rerank_start = time.time()

            # Convert LangChain documents to format acceptable by ranking service
            doc_dicts = [
                {
                    'content': doc.page_content,
                    'metadata': doc.metadata,
                    'score': 1.0  # Initial retrieval score
                }
                for doc in docs
            ]

            # Rerank documents
            reranked = self.ranking_service.rank(query, doc_dicts, top_k=top_k)

            rerank_time = time.time() - rerank_start
            logger.debug(f"Reranking took {rerank_time:.3f}s")

            # Track reranking metrics
            reranking_queries_total.labels(reranker_type=self.ranking_service.strategy).inc()
            reranking_duration_seconds.labels(reranker_type=self.ranking_service.strategy).observe(rerank_time)

            # Convert back to LangChain Document objects with updated metadata
            from langchain_core.documents import Document

            docs = [
                Document(
                    page_content=doc['content'],
                    metadata={
                        **doc['metadata'],
                        'original_score': doc['original_score'],
                        'rerank_score': doc['rerank_score'],
                        'combined_score': doc['combined_score']
                    }
                )
                for doc in reranked
            ]

        return docs[:top_k]

    # -------------------------------------------------------------------
    # FIX #5: shared internal helper used by both ask() and ask_stream()
    # so retrieval + local caching + logging logic exists in ONE place.
    # -------------------------------------------------------------------
    def _build_cache_key(self, query: str) -> str:
        return f"{self.tenant_id}:{hashlib.md5(query.encode()).hexdigest()}"

    def _get_cached(self, cache_key: str):
        with _query_cache_lock:
            return _query_cache.get(cache_key)

    def _set_cached(self, cache_key: str, value: dict):
        with _query_cache_lock:
            _query_cache[cache_key] = value

    def _log_run(self, query, full_answer, latency, cache_hit, retrieved_docs_ids,
                 input_tokens, output_tokens, model_name):
        if not self.db:
            return
        try:
            trigger_query_logging(
                tenant_id=self.tenant_id,
                query=query,
                answer=full_answer,
                latency=latency,
                cache_hit=cache_hit,
                retrieved_docs_ids=retrieved_docs_ids,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                model_name=model_name
            )
            logger.debug(f"Queued background logging for query: {query[:50]}...")
        except Exception as e:
            logger.error(f"Error queuing background logging: {e}")

    def _stream_answer(self, query: str, use_local_cache: bool):
        """
        Core streaming implementation shared by ask() and ask_stream().

        Yields answer chunks and, once exhausted, has already queued
        background logging as a side effect (mirrors previous behavior).

        Args:
            query: user question
            use_local_cache: whether to check/populate the local in-memory
                query cache (ask_stream() opts in; ask() previously did not,
                kept as an explicit flag rather than duplicated logic)
        """
        start_time = time.time()
        full_answer = ""
        cache_hit = False
        cache_source = "NONE"
        cache_key = self._build_cache_key(query)

        # 1. Check local query cache first (fastest) -- FIX #4: TTLCache is
        # self-expiring and access is guarded by a lock, so no manual
        # expired-key sweep and no race condition under concurrent requests.
        if use_local_cache:
            cached_result = self._get_cached(cache_key)
            if cached_result is not None:
                cache_hit = True
                cache_source = "LOCAL_MEMORY"
                cache_hits_total.labels(cache_type="local_memory").inc()
                logger.info(f"[⚡ CACHE HIT - LOCAL MEMORY] Returning cached result for: {query[:50]}...")
                full_answer = cached_result['answer']
                yield full_answer

                latency = time.time() - start_time
                retrieved_docs_ids = cached_result.get('docs_ids', '')
                self._log_run(
                    query, full_answer, latency, True, retrieved_docs_ids,
                    0, 0, "Qwen2.5-1.5B (CACHED)"
                )
                return

            logger.info(f"[🔄 CACHE MISS - LOCAL MEMORY] Generating new answer for: {query[:50]}...")

        # 2. Get reranked documents if reranker is enabled
        docs = self.retrieve(query) if self.use_reranker else self.retriever.invoke(query)

        logger.info(f"Starting answer generation for query: {query[:50]}...")
        logger.info(f"Number of context documents: {len(docs)}")

        # -----------------------------------------------------------
        # FIX #3: previously "was this a Redis cache hit" was guessed
        # purely from wall-clock latency (< 1.5s), which is unreliable
        # (a warm GPU or a short query can also be fast, and a busy
        # Redis instance can be slow even on a real hit). We now ask the
        # configured cache object directly via its `lookup()` API before
        # streaming, which is what LangChain itself uses internally to
        # decide whether to call the LLM at all.
        # -----------------------------------------------------------
        redis_cache = get_llm_cache()
        cache_probably_hit = False
        if redis_cache is not None:
            try:
                # RedisSemanticCache.lookup(prompt, llm_string) returns the
                # cached generations if a semantically similar entry exists,
                # or None otherwise. Using the actual cache lookup instead of
                # a timing heuristic gives a ground-truth answer.
                llm_string = getattr(self.local_llm, "_llm_type", "custom_huggingface_stream")
                cache_probably_hit = redis_cache.lookup(query, llm_string) is not None
            except Exception as e:
                logger.debug(f"Redis cache lookup check failed (non-fatal): {e}")

        llm_start_time = time.time()
        for chunk in self.document_chain.stream({"input": query, "context": docs}):
            if isinstance(chunk, dict):
                for key, value in chunk.items():
                    if isinstance(value, str) and value.strip():
                        full_answer += value
                        yield value
            elif isinstance(chunk, str):
                full_answer += chunk
                yield chunk
        llm_time = time.time() - llm_start_time

        if cache_probably_hit and full_answer:
            logger.info(f"[⚡ REDIS CACHE HIT] LLM response time: {llm_time:.2f}s")
            cache_source = "REDIS"
            cache_hit = True
            cache_hits_total.labels(cache_type="redis").inc()
        else:
            logger.info(f"[🔄 LLM GENERATED NEW RESPONSE] Response time: {llm_time:.2f}s (Redis available: {redis_cache is not None})")
            cache_source = "LLM_GENERATED"
            cache_hit = False
            cache_misses_total.labels(cache_type="redis").inc()

        logger.info(f"Answer generation completed. Length: {len(full_answer)} chars")

        # Calculate metrics after streaming completes
        latency = time.time() - start_time
        usage = CustomLocalLLM.last_usage or {}
        input_tokens = usage.get("input", 0)
        output_tokens = usage.get("output", 0)
        # FIX #7: pricing pulled from settings (with a safe fallback) instead
        # of being hardcoded inline, so a model/pricing change only needs to
        # be updated in one place (app.core.config.settings).
        cost = (input_tokens * _INPUT_TOKEN_COST) + (output_tokens * _OUTPUT_TOKEN_COST)
        retrieved_docs_ids = ",".join([doc.metadata.get('_id', '') for doc in docs])

        if use_local_cache:
            self._set_cached(cache_key, {
                'answer': full_answer,
                'docs_ids': retrieved_docs_ids,
                'timestamp': time.time()
            })
            logger.info("✅ Query result cached in local memory")

        logger.info(
            f"Query processed - Latency: {latency:.2f}s, Cache: {cache_source}, "
            f"Docs: {len(docs)}, Cost: ${cost:.6f}"
        )

        self._log_run(
            query, full_answer, latency, cache_hit, retrieved_docs_ids,
            input_tokens, output_tokens, "Qwen2.5-1.5B"
        )

    def ask(self, query: str):
        """
        Answer the question using the Cache and the local LLM.

        Now shares the exact same retrieval/caching/logging path as
        ask_stream() (FIX #5) -- previously this method silently skipped
        local-memory caching and Redis-hit detection that ask_stream() had,
        which was a source of divergent/confusing behavior.
        """
        yield from self._stream_answer(query, use_local_cache=True)

    def ask_stream(self, query: str):
        """
        Stream the answer to a query with logging of run and cost information.

        Three-layer caching:
        1. Local query cache (_query_cache, TTLCache) - stores full query+answer results
        2. Redis Semantic Cache (tenant-scoped) - caches LLM responses for similar queries
        3. Database - logs all queries for analytics
        """
        yield from self._stream_answer(query, use_local_cache=True)

    @property
    def _llm_type(self) -> str:
        return "custom_huggingface_stream"